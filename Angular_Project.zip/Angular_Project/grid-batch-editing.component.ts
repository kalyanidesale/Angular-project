public commit() { 
    let addResult: { [id: number]: City}; 
    
    this.cityService.commitCities(this.grid.transactions.getAggregatedChanges(true)) 
         .subscribe(res => { 
             if (res) { 
               addResult = res; 
             } 
           }, 
           err => this.errors = err, 
           () => { 
             // all done, commit transactions 
             this.grid.transactions.commit(this.data); 
             if (!addResult) { 
               return; 
             } 
             // update added records IDs with ones generated from backend 
             for (const id of Object.keys(addResult)) { 
               const item = this.data.find(x => x.CityID === parseInt(id, 10)); 
               item.CityID = addResult[id].CityID; 
             } 
             this.data = [...this.data]; 
           } 
         ); 
     } 

function commit() {
  throw new Error("Function not implemented.");
}
