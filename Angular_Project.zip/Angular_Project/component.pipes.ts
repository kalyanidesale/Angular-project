import { Pipe, PipeTransform } from "@angular/core";
import { Transaction } from "transaction";
import { TransactionService } from "transaction.service";

@Pipe({
    name: 'tableTransaction',
    pure: true
  })
   
  export class TableTransactionPipe implements PipeTransform {
  
    constructor(private transactions: TransactionService) { } 
  
    transform(collection: any[], pipeTrigger: number) {
      if (collection && this.transactions.enabled) {
        const changes: Transaction[] = this.transactions.getAggregatedChanges(true);
        // Update the data source with the aggregated changes and return the result
      } else {
        // If there are not any transactions, return the original collection
        return collection;
      }
    }
  }