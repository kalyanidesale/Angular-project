import { Transaction } from "transaction";
const transaction: Transaction = { id: transactionId, type: TransactionType.ADD, newValue: data };
this.transactions.add(transaction);