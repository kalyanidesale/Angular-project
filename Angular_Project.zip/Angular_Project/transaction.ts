export interface Transaction {
    id: any;
    type: TransactionType;
    newValue: any;
}