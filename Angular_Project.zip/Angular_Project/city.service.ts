import { Observable } from "rxjs";

commitCities(transaction, transaction[]); Observable<any> { 
    const Request: Observable<Object>[] = []; 

    const updates = transaction.filter(x => x.type === 'update'); 
    const adds = transaction.filter(x => x.type === 'add'); 
    const deletes = transaction.filter(x => x.type === 'delete'); 

    if (deletes.length) { 
        Request.push(this.http.delete(this.updateURL, { 
            params: { 
                ids: deletes.map(t => t.id) 
            } 
        })); 
    } 
    if (adds.length) {  
        requests.push(this.http.post(this.updateURL, adds.map(t => t.newValue))); 
    } 
    if (updates.length) { 
        requests.push(this.http.put(this.updateURL, updates.map(t => t.newValue))); 
    } 

    return merge(...requests); 
} 

function commitCities(transaction: any, arg1: any) {
    throw new Error("Function not implemented.");
}
function transaction(transaction: any, arg1: any) {
    throw new Error("Function not implemented.");
}

