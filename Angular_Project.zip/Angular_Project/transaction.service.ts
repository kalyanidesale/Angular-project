import * as EventEmitter from "events";
import { Transaction } from "transaction";



export interface TransactionService {
    readonly enabled: boolean;
    /** Event fired when transaction state has changed */
    onStateUpdate?: EventEmitter<void>;
    /** Add transaction */
    add(transaction: Transaction, originalRecord?: any): void;
    /** Returns aggregated changes from all transactions */
    getAggregatedChanges(mergeValueWithOriginal: boolean): Transaction[];
    /** Applies all transactions over the provided data */
    commit(data: any[]): void;
    /** Clears all transactions */
    clear(): void;
    /** Remove the last transaction */
    undo(): void;
    /** Apply back the last undone transaction */
    redo(): void;
    /** Start recording transactions into a pending state */
    startPending(): void;
    /** Stop recording and add pending state as single transaction */
    endPending(): void;
  }