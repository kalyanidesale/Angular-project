import { Component } from "@angular/core"; 
import { IgxTransactionService } from "igniteui-angular"; 
 
@Component({ 
    providers: [IgxTransactionService], 
    selector: "my-table", 
    ...
}) 
export class MyTableComponent { } 
public get undoEnabled(): boolean {
    return this.table.transactions.canUndo;
}
 
public get redoEnabled(): boolean {
    return this.table.transactions.canRedo;
}
 
public undo() {
    this.table.transactions.undo();
}
 
public redo() {
    this.table.transactions.redo();
}
 
public commit() {
    this.table.transactions.commit(this.data);
}
 
public discard() {
    this.table.transactions.clear();
}

function discard() {
    throw new Error("Function not implemented.");
}
function undoEnabled() {
    throw new Error("Function not implemented.");
}

function redo() {
    throw new Error("Function not implemented.");
}

function commit() {
    throw new Error("Function not implemented.");
}

function redoEnabled() {
    throw new Error("Function not implemented.");
}

